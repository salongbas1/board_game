// ============================================================
// ข้อมูลตัวละคร D&D — เผ่าพันธุ์ (races), คลาส (classes), ทรงผม/หน้าตา,
// อุปกรณ์เริ่มต้นตามคลาส, ตารางเลเวล/EXP, และค่าคะแนนสร้างตัวละคร
// ============================================================

const DND_RACES = [
  { key: 'human',      name: 'มนุษย์',        icon: '🧑', desc: 'ปรับตัวเก่ง เรียนรู้ไว เป็นได้ทุกอย่าง',       bonus: { str: 1, dex: 1, con: 1 } },
  { key: 'elf',        name: 'เอลฟ์',         icon: '🧝', desc: 'ปราดเปรียว สายตาดี ผูกพันกับเวทมนตร์',        bonus: { dex: 2, int: 1 } },
  { key: 'dwarf',      name: 'ดวาร์ฟ',        icon: '🧔', desc: 'แข็งแกร่ง ทนทาน ช่างฝีมือใต้ภูเขา',           bonus: { con: 2, str: 1 } },
  { key: 'halfling',   name: 'ฮาล์ฟลิง',      icon: '🍀', desc: 'ตัวเล็ก ปราดเปรียว โชคดีเป็นพิเศษ',           bonus: { dex: 2, cha: 1 } },
  { key: 'orc',        name: 'ออร์ค',         icon: '💪', desc: 'พละกำลังมหาศาล ดุดันในสนามรบ',               bonus: { str: 2, con: 1 } },
  { key: 'tiefling',   name: 'ทิฟลิง',        icon: '😈', desc: 'สายเลือดปีศาจ เสน่ห์ล้ำลึก',                  bonus: { cha: 2, int: 1 } },
  { key: 'gnome',      name: 'โนม',           icon: '🎩', desc: 'ฉลาดหลักแหลม ช่างประดิษฐ์',                   bonus: { int: 2, dex: 1 } },
  { key: 'dragonborn', name: 'ดราก้อนบอร์น', icon: '🐉', desc: 'สายเลือดมังกร พลังและศักดิ์ศรี',              bonus: { str: 2, cha: 1 } },
  { key: 'medusa',     name: 'เมดูซ่า',       icon: '🐍', desc: 'เผ่าพันธุ์งูในตำนาน สายตาต้องมนตร์ เคลื่อนไหวปราดเปรียวและมีเสน่ห์ลึกลับ', bonus: { dex: 2, cha: 1 } },
  { key: 'aasimar',    name: 'อาซิมาร์',      icon: '😇', desc: 'สายเลือดเทวะ แบกรับแสงสว่างศักดิ์สิทธิ์ไว้ในกาย',              bonus: { cha: 2, wis: 1 } },
  { key: 'goliath',    name: 'โกไลแอธ',       icon: '🏔️', desc: 'ยักษ์แห่งขุนเขา ร่างกายบึกบึนและอึดทรหด',                     bonus: { str: 2, con: 1 } },
  { key: 'halfElf',    name: 'ครึ่งเอลฟ์',    icon: '🌗', desc: 'สายเลือดผสมมนุษย์และเอลฟ์ ปรับตัวได้รอบด้านและมีเสน่ห์',      bonus: { cha: 2, dex: 1 } },
  { key: 'halfOrc',    name: 'ครึ่งออร์ค',    icon: '💢', desc: 'สายเลือดผสมมนุษย์และออร์ค แข็งแกร่งและอดทนในสนามรบ',          bonus: { str: 2, con: 1 } },
  { key: 'aarakocra',  name: 'อารักโคครา',    icon: '🦅', desc: 'เผ่าพันธุ์นกในตำนาน มีปีกโบกบินและกรงเล็บแหลมคม',              bonus: { dex: 2, wis: 1 } },
  { key: 'astralElf',  name: 'แอสทรัลเอลฟ์',  icon: '✨', desc: 'เอลฟ์จากภาคพื้นดาราจักร เคลื่อนไหวราวกับแสงดาว',               bonus: { cha: 2, wis: 1 } },
  { key: 'autognome',  name: 'ออโต้โนม',      icon: '🤖', desc: 'หุ่นยนต์จิ๋วมีจิตวิญญาณ ร่างกายทำจากโลหะแข็งแกร่ง',            bonus: { con: 2, int: 1 } },
  { key: 'bugbear',    name: 'บั๊กแบร์',      icon: '🐻', desc: 'ยักษ์ขนดกญาติของกอบลิน แขนขายาวและจู่โจมไม่ทันตั้งตัว',        bonus: { str: 2, dex: 1 } },
  { key: 'centaur',    name: 'เซนทอร์',       icon: '🐎', desc: 'กึ่งมนุษย์กึ่งม้า ผูกพันกับธรรมชาติและการพุ่งชน',              bonus: { str: 2, wis: 1 } },
  { key: 'changeling', name: 'เชนจ์ลิง',      icon: '🎭', desc: 'แปลงกายได้อย่างแนบเนียน ผู้เชี่ยวชาญด้านการลวงตา',             bonus: { cha: 2, dex: 1 } },
  { key: 'deepGnome',  name: 'ดีปโนม',        icon: '⛏️', desc: 'โนมแห่งใต้พิภพ ชำนาญการซ่อนตัวและพรางกาย',                    bonus: { dex: 2, int: 1 } },
  { key: 'dhampir',    name: 'แดมเปียร์',     icon: '🧛', desc: 'สายเลือดกึ่งแวมไพร์ ปราดเปรียวและมีเสน่ห์ลึกลับ',              bonus: { dex: 2, cha: 1 } },
  { key: 'duergar',    name: 'ดูเออร์การ์',   icon: '⛏️', desc: 'ดวาร์ฟใต้พิภพ ผูกพันกับเวทมนตร์และความทรหด',                 bonus: { con: 2, int: 1 } },
  { key: 'eladrin',    name: 'เอลาดริน',      icon: '🍃', desc: 'เอลฟ์แห่งเฟย์ไวลด์ ผูกพันกับฤดูกาลและเวทมนตร์',               bonus: { int: 2, wis: 1 } },
  { key: 'fairy',      name: 'แฟรี่',         icon: '🧚', desc: 'ภูตปีกน้อยลึกลับ ร่ายเวทและโบยบินได้อย่างว่องไว',              bonus: { dex: 2, int: 1 } },
  { key: 'firbolg',    name: 'เฟียร์โบลก์',   icon: '🌲', desc: 'ญาติห่าง ๆ ของยักษ์ ผูกพันกับป่าลึกและเวทมนตร์',              bonus: { wis: 2, str: 1 } },
  { key: 'genasi',     name: 'เจนาไซ',        icon: '🌊', desc: 'ลูกครึ่งเทพธาตุ พลังธาตุไหลเวียนอยู่ในสายเลือด',              bonus: { con: 2, str: 1 } },
  { key: 'giff',       name: 'กิฟฟ์',         icon: '🦛', desc: 'นักรบฮิปโปจากห้วงอวกาศ กำยำและถนัดอาวุธปืนใหญ่',              bonus: { str: 2, con: 1 } },
  { key: 'githyanki',  name: 'กิธยันกิ',      icon: '⚔️', desc: 'นักรบแห่งภาคพื้นดารา ฝึกฝนดาบมาอย่างโชกโชน',                  bonus: { str: 2, int: 1 } },
  { key: 'githzerai',  name: 'กิธเซไร',       icon: '🧘', desc: 'นักพรตแห่งลิมโบ ฝึกจิตจนแกร่งกล้าเหนือผู้อื่น',               bonus: { wis: 2, int: 1 } },
  { key: 'goblin',     name: 'กอบลิน',        icon: '👺', desc: 'ตัวเล็กปราดเปรียว ใช้ไหวพริบเอาตัวรอดในสนามรบ',               bonus: { dex: 2, con: 1 } },
  { key: 'hadozee',    name: 'แฮโดซี',        icon: '🐒', desc: 'เผ่าพันธุ์คล้ายลิง มีพังผืดใต้แขนไว้ร่อนลม',                  bonus: { dex: 2, con: 1 } },
  { key: 'harengon',   name: 'แฮเรงกอน',      icon: '🐇', desc: 'เผ่าเฟย์รูปกระต่าย ปราดเปรียวและโชคดีเป็นพิเศษ',              bonus: { dex: 2, wis: 1 } },
  { key: 'hexblood',   name: 'เฮ็กซ์บลัด',    icon: '🩸', desc: 'ผู้ถูกแปรสภาพด้วยเวทมนตร์แม่มด แฝงพลังลึกลับ',                bonus: { cha: 2, con: 1 } },
  { key: 'hobgoblin',  name: 'ฮ็อบกอบลิน',    icon: '🗡️', desc: 'นักรบมีระเบียบวินัยสูง ผูกพันกับเฟย์ไวลด์',                   bonus: { con: 2, str: 1 } },
  { key: 'kalashtar',  name: 'คาลาชตาร์',     icon: '🌙', desc: 'สายเลือดผสานวิญญาณแห่งภาคพื้นฝัน มีพลังจิตล้ำลึก',            bonus: { wis: 2, cha: 1 } },
  { key: 'kender',     name: 'เคนเดอร์',      icon: '🎒', desc: 'นักผจญภัยตัวเล็กผู้กล้าหาญและอยากรู้อยากเห็น',                bonus: { dex: 2, cha: 1 } },
  { key: 'kenku',      name: 'เค็นคุ',        icon: '🐦‍⬛', desc: 'เผ่าพันธุ์รูปกาผู้เชี่ยวชาญการเลียนเสียงและฝีมือ',              bonus: { dex: 2, wis: 1 } },
  { key: 'kobold',     name: 'คอบโบลด์',      icon: '🦎', desc: 'สัตว์เลื้อยคลานตัวเล็ก ชำนาญกับดักและล่าเป็นฝูง',             bonus: { dex: 2, int: 1 } },
  { key: 'leonin',     name: 'ลีโอนิน',       icon: '🦁', desc: 'นักรบสิงโต ทรงพลังและคำรามข่มขวัญศัตรูได้',                   bonus: { con: 2, str: 1 } },
  { key: 'lizardfolk', name: 'ลิซาร์ดโฟล์ค',  icon: '🦎', desc: 'สัตว์เลื้อยคลานสายพันธุ์นักล่า เกล็ดหนาและกัดได้แรง',          bonus: { con: 2, wis: 1 } },
  { key: 'loxodon',    name: 'ล็อกโซดอน',     icon: '🐘', desc: 'มนุษย์ช้าง งวงทรงพลังและผิวหนังหนาราวเกราะ',                  bonus: { con: 2, wis: 1 } },
  { key: 'minotaur',   name: 'มิโนทอร์',      icon: '🐂', desc: 'นักรบเขาวัว เขาแหลมคมและความจำเขาวงกตเป็นเลิศ',               bonus: { str: 2, con: 1 } },
  { key: 'owlin',      name: 'อาวลิน',        icon: '🦉', desc: 'มนุษย์นกฮูก บินเงียบและมองเห็นในความมืดได้ไกล',               bonus: { dex: 2, wis: 1 } },
  { key: 'plasmoid',   name: 'พลาสมอยด์',     icon: '🟢', desc: 'ร่างวุ้นไร้รูปทรง สามารถบีบตัวลอดผ่านช่องแคบได้',             bonus: { con: 2, dex: 1 } },
  { key: 'reborn',     name: 'รีบอร์น',       icon: '💀', desc: 'ผู้ฟื้นคืนชีพจากความตาย ร่างกายแฝงรอยแผลแห่งอดีต',            bonus: { con: 2, int: 1 } },
  { key: 'satyr',      name: 'ซาเทียร์',      icon: '🐐', desc: 'เผ่าเฟย์รูปแพะ ร่าเริงและผูกพันกับเวทมนตร์',                  bonus: { cha: 2, dex: 1 } },
  { key: 'seaElf',     name: 'ซีเอลฟ์',       icon: '🌊', desc: 'เอลฟ์แห่งท้องทะเล ว่ายน้ำเก่งและหายใจใต้น้ำได้',              bonus: { dex: 2, con: 1 } },
  { key: 'shadarKai',  name: 'ชาดาร์ไค',      icon: '🖤', desc: 'เอลฟ์แห่งเงามืด รับใช้ราชินีอีกาแห่งแดนเงา',                  bonus: { dex: 2, wis: 1 } },
  { key: 'shifter',    name: 'ชิฟเตอร์',      icon: '🐺', desc: 'สายเลือดกึ่งมนุษย์หมาป่า แปรสภาพร่างได้ในยามศึก',             bonus: { str: 2, dex: 1 } },
  { key: 'simicHybrid',name: 'ซิมิกไฮบริด',   icon: '🐸', desc: 'มนุษย์ผสมสัตว์น้ำ ปรับตัวเข้ากับสภาพแวดล้อมได้ดี',            bonus: { con: 2, dex: 1 } },
  { key: 'tabaxi',     name: 'ทาแบ็กซี',      icon: '🐈', desc: 'มนุษย์แมว ปราดเปรียวและอยากรู้อยากเห็นไม่มีที่สิ้นสุด',       bonus: { dex: 2, cha: 1 } },
  { key: 'thriKreen',  name: 'ธริครีน',       icon: '🦗', desc: 'แมลงยักษ์สี่แขนจากห้วงอวกาศ ว่องไวและมีพลังจิต',              bonus: { dex: 2, str: 1 } },
  { key: 'tortle',     name: 'ทอร์เทิล',      icon: '🐢', desc: 'มนุษย์เต่า กระดองแข็งแกร่งปกป้องร่างกายได้ดีเยี่ยม',          bonus: { con: 2, wis: 1 } },
  { key: 'triton',     name: 'ไทรทัน',        icon: '🔱', desc: 'ผู้พิทักษ์ห้วงสมุทรลึก แข็งแกร่งและควบคุมสายน้ำได้',          bonus: { str: 2, cha: 1 } },
  { key: 'vedalken',   name: 'เวดัลเคน',      icon: '🧠', desc: 'มนุษย์ผิวสีฟ้าผู้ชาญฉลาด จิตใจสงบนิ่งเยือกเย็น',              bonus: { int: 2, wis: 1 } },
  { key: 'verdan',     name: 'เวอร์แดน',      icon: '💚', desc: 'สายเลือดกอบลินอยด์ผู้มีสัมผัสพิเศษด้านจิตสัมผัส',             bonus: { cha: 2, con: 1 } },
  { key: 'warforged',  name: 'วอร์ฟอร์จ',     icon: '⚙️', desc: 'ทหารกลไกที่ตื่นรู้ ร่างกายแข็งแกร่งดุจเกราะเหล็ก',            bonus: { con: 2, str: 1 } },
  { key: 'yuanTi',     name: 'ยวนที',         icon: '🐍', desc: 'ลูกผสมมนุษย์งู แฝงเวทมนตร์และต้านทานพิษ',                    bonus: { cha: 2, int: 1 } },
];
const DND_CLASSES = [
  { key: 'fighter',    name: 'นักรบ',       icon: '⚔️', desc: 'ผู้เชี่ยวชาญการต่อสู้ระยะประชิด',       bonus: { str: 2, con: 1 }, hitDie: 10, armor: 'heavy' },
  { key: 'wizard',     name: 'นักเวท',      icon: '🔮', desc: 'ควบคุมเวทมนตร์อันทรงพลัง',              bonus: { int: 2, wis: 1 }, hitDie: 6,  armor: 'light' },
  { key: 'cleric',     name: 'นักบวช',      icon: '✨', desc: 'ผู้รับใช้เทพเจ้า รักษาและปกป้องปาร์ตี้',  bonus: { wis: 2, con: 1 }, hitDie: 8,  armor: 'medium' },
  { key: 'rogue',      name: 'โจร',         icon: '🗡️', desc: 'คล่องแคล่ว หลบหลีก จู่โจมจุดอ่อน',      bonus: { dex: 2, cha: 1 }, hitDie: 8,  armor: 'light' },
  { key: 'ranger',     name: 'เรนเจอร์',    icon: '🏹', desc: 'นักล่าแห่งป่าเถื่อน แม่นธนู',            bonus: { dex: 2, wis: 1 }, hitDie: 10, armor: 'medium' },
  { key: 'barbarian',  name: 'บาร์บาเรียน', icon: '🪓', desc: 'พลังดิบ ความดุร้ายที่ไม่มีใครหยุดได้',    bonus: { str: 2, con: 1 }, hitDie: 12, armor: 'medium' },
  { key: 'paladin',    name: 'พาลาดิน',     icon: '🛡️', desc: 'นักรบศักดิ์สิทธิ์ผู้ปกป้องความยุติธรรม',  bonus: { cha: 2, str: 1 }, hitDie: 10, armor: 'heavy' },
  { key: 'bard',       name: 'บาร์ด',       icon: '🎵', desc: 'เสน่ห์และดนตรี สร้างแรงบันดาลใจให้ปาร์ตี้', bonus: { cha: 2, dex: 1 }, hitDie: 8,  armor: 'light' },
];
const DND_CLASS_STARTER_GEAR = {
  fighter:   { weapon: { name: 'ดาบยาว',        atk: 2, def: 0, maxDurability: 10 }, armor: { name: 'เกราะโซ่',         atk: 0, def: 2, maxDurability: 10 }, shoes: { name: 'รองเท้าบูทเกราะ',  atk: 0, def: 1, maxDurability: 8 }, accessory: { name: 'โล่ไม้',           atk: 0, def: 1, maxDurability: 6 } },
  wizard:    { weapon: { name: 'ไม้เท้าเวทย์',   atk: 1, def: 0, maxDurability: 6  }, armor: { name: 'เสื้อคลุมนักเวท',  atk: 0, def: 1, maxDurability: 6  }, shoes: { name: 'รองเท้าผ้า',        atk: 0, def: 0, maxDurability: 4 }, accessory: { name: 'ตำราคาถา',        atk: 1, def: 0, maxDurability: 6 } },
  cleric:    { weapon: { name: 'ตะบองศักดิ์สิทธิ์', atk: 1, def: 0, maxDurability: 8 }, armor: { name: 'เกราะโซ่นักบวช',  atk: 0, def: 2, maxDurability: 8  }, shoes: { name: 'รองเท้าหนัง',        atk: 0, def: 1, maxDurability: 6 }, accessory: { name: 'สัญลักษณ์ศักดิ์สิทธิ์', atk: 0, def: 1, maxDurability: 6 } },
  rogue:     { weapon: { name: 'กริชคู่',        atk: 2, def: 0, maxDurability: 8  }, armor: { name: 'เสื้อหนังนุ่ม',    atk: 0, def: 1, maxDurability: 6  }, shoes: { name: 'รองเท้าย่องเบา',     atk: 0, def: 1, maxDurability: 6 }, accessory: { name: 'ชุดเครื่องมือโจร', atk: 1, def: 0, maxDurability: 6 } },
  ranger:    { weapon: { name: 'ธนูสั้น',        atk: 2, def: 0, maxDurability: 8  }, armor: { name: 'เกราะหนัง',        atk: 0, def: 2, maxDurability: 8  }, shoes: { name: 'รองเท้าเดินป่า',     atk: 0, def: 1, maxDurability: 6 }, accessory: { name: 'แล่งธนู',          atk: 1, def: 0, maxDurability: 6 } },
  barbarian: { weapon: { name: 'ขวานใหญ่',       atk: 3, def: 0, maxDurability: 10 }, armor: { name: 'ชุดหนังสัตว์',     atk: 0, def: 1, maxDurability: 8  }, shoes: { name: 'รองเท้าหนังหยาบ',    atk: 0, def: 1, maxDurability: 6 }, accessory: { name: 'สร้อยเขี้ยวสัตว์', atk: 1, def: 0, maxDurability: 4 } },
  paladin:   { weapon: { name: 'ดาบยาว',        atk: 2, def: 0, maxDurability: 10 }, armor: { name: 'เกราะแผ่นเหล็ก',   atk: 0, def: 3, maxDurability: 10 }, shoes: { name: 'รองเท้าบูทเหล็ก',    atk: 0, def: 1, maxDurability: 8 }, accessory: { name: 'โล่ประจำตระกูล',   atk: 0, def: 1, maxDurability: 6 } },
  bard:      { weapon: { name: 'กระบี่สั้น',     atk: 1, def: 0, maxDurability: 6  }, armor: { name: 'เสื้อคลุมนักแสดง', atk: 0, def: 1, maxDurability: 6  }, shoes: { name: 'รองเท้าผ้านิ่ม',     atk: 0, def: 0, maxDurability: 4 }, accessory: { name: 'พิณคู่ใจ',         atk: 1, def: 0, maxDurability: 6 } },
};
const DND_HAIR_STYLES = ['bald', 'short', 'long', 'mohawk', 'ponytail'];
const DND_HAIR_COLORS = ['#2b1b12', '#5b3a1e', '#8a5a2b', '#c9a227', '#e8e2d0', '#7a3b2e', '#3b3b3b', '#c94f4f'];
const DND_FACE_STYLES = ['neutral', 'smile', 'serious', 'surprised', 'wink'];
const DND_LEVEL_EXP = [
  0, 300, 900, 2700, 6500, 14000, 23000, 34000, 48000, 64000,
  85000, 100000, 120000, 140000, 165000, 195000, 225000, 265000, 305000, 355000
];
const DND_POINT_BUY_TOTAL = 72;
const DND_STARTING_GOLD_MAX = 200; // เพดานทองเริ่มต้นที่ผู้เล่นกรอกเองได้ตอนสร้างตัวละคร กัน exploit
const DND_STARTING_SP = 1; // SP (Skill Point / Mana) เริ่มต้นของตัวละครทุกคน = 1 คงที่ — DM ปรับเพิ่ม/ลด (ทั้งปัจจุบันและสูงสุด) เองทีหลังผ่านหน้าต่างแก้ไขผู้เล่น
module.exports = {
  DND_RACES, DND_CLASSES, DND_CLASS_STARTER_GEAR,
  DND_HAIR_STYLES, DND_HAIR_COLORS, DND_FACE_STYLES,
  DND_LEVEL_EXP, DND_POINT_BUY_TOTAL, DND_STARTING_GOLD_MAX, DND_STARTING_SP,
};
